
file="/etc/protocols"

while IFS= read line
do
        if [[ $line == *"udp"* ]] || [[ $line == *"idrp"* ]] || [[ $line == *"skip"* ]] || [[ $line == *"ipip"* ]]
        then
         echo "$line" 
fi
done <"$file" >favoriteprotocols.txt
cat favoriteprotocols.txt


