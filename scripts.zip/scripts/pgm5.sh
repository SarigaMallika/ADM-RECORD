echo "Enter twenty food items"
cat > twentyfoods.txt
echo "File is created"

