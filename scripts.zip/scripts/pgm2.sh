echo "Enter First Number"
read num1
echo "Enter Second Number"
read num2

if [ $num1 -gt $num2 ]
then
    echo Greatest number is$num1
else
    echo Greatest number is$num2
fi

