echo Enter name
read name
echo welcome $name
