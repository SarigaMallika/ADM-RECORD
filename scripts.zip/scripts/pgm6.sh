awk '{ gsub("C|c","d"); print $1 }' twentyfoods.txt

