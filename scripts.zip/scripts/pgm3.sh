echo The first 20 odd numbers are..
for i in {1..40}

do
        rem=$(($i % 2))
        if [ "$rem" -ne "0" ]; then
                echo $i
        fi
done
