array=( 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20)
sum=0
	echo "Stored numbers are ${array[*]}"
        for i in ${array[@]};
        do
              sum=`expr $sum + $i`  
        done
        echo "Total =$sum"
